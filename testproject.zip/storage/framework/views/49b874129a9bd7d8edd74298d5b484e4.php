<?php if(session('thong-bao')): ?>
<div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<strong style="font-size: 1rem"><?php echo e(session('thong-bao')); ?></strong>
</div>
<?php endif; ?><?php /**PATH D:\Users\ADMIN\Desktop\test_project\backup_crudcars\testproject\resources\views/layouts/notification.blade.php ENDPATH**/ ?>