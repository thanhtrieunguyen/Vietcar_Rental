

<?php $__env->startSection('content'); ?>
    <div class="row my-4">
        <div class="col-6 offset-3">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <h5 class="card-title text-center text-uppercase mt-4">Đăng ký</h5>
                    <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('auth.dangky')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                name="email" placeholder="Nhập email"  value="<?php echo e(old('email')); ?>">

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                name="password" placeholder="Nhập mật khẩu" >

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password_confirmation"
                                placeholder="Nhập lại mật khẩu" >
                        </div>
                        <div class="form-row my-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control<?php echo e($errors->has('hoten') ? ' is-invalid' : ''); ?>"
                                    name="hoten" placeholder="Nhập họ tên"  value="<?php echo e(old('hoten')); ?>">

                                <?php if($errors->has('hoten')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('hoten')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control<?php echo e($errors->has('cccd') ? ' is-invalid' : ''); ?>"
                                    name="cccd" placeholder="Nhập CCCD"  value="<?php echo e(old('cccd')); ?>">

                                <?php if($errors->has('cccd')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('cccd')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-row my-3">
                            <div class="col-md-6">
                                <input type="date" class="form-control" name="ngaysinh" placeholder="Chọn ngày sinh"
                                     value="<?php echo e(old('ngaysinh')); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control<?php echo e($errors->has('sdt') ? ' is-invalid' : ''); ?>"
                                    name="sdt" placeholder="Nhập số điện thoại"  value="<?php echo e(old('sdt')); ?>">

                                <?php if($errors->has('sdt')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('sdt')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <textarea type="text" class="form-control<?php echo e($errors->has('diachi') ? ' is-invalid' : ''); ?>" name="diachi"
                                rows="2" placeholder="Nhập địa chỉ" ><?php echo e(old('diachi')); ?></textarea>

                            <?php if($errors->has('diachi')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('diachi')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-dark btn-block mt-4">Đăng ký</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\ADMIN\Desktop\test_project\backup_crudcars\testproject\resources\views/pages/dangky.blade.php ENDPATH**/ ?>